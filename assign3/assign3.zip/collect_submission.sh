rm -f assign3_*.zip
zip -r assign3_YOURNAME_YOURNUMBER.zip *.py *.png *_final.pth
