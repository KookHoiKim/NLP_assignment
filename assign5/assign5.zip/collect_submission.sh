rm -f assign5_*.zip
zip -r assign5_YOURNAME_YOURNUMBER.zip *.py dev-v1.1-TA-answers.json
