rm -f assign2_*.zip
zip -r assign2_YOURNAME_YOURNUMBER.zip *.py *.png