mkdir data
wget -O data/train.en.txt https://raw.githubusercontent.com/multi30k/dataset/master/data/task1/tok/train.lc.norm.tok.en 
wget -O data/train.fr.txt https://raw.githubusercontent.com/multi30k/dataset/master/data/task1/tok/train.lc.norm.tok.fr
wget -O data/val.en.txt https://raw.githubusercontent.com/multi30k/dataset/master/data/task1/tok/val.lc.norm.tok.en
wget -O data/val.fr.txt https://raw.githubusercontent.com/multi30k/dataset/master/data/task1/tok/val.lc.norm.tok.fr
wget -O data/test.en.txt https://raw.githubusercontent.com/multi30k/dataset/master/data/task1/tok/test_2017_mscoco.lc.norm.tok.en
wget -O data/test.fr.txt https://raw.githubusercontent.com/multi30k/dataset/master/data/task1/tok/test_2017_mscoco.lc.norm.tok.fr
wget -O data/README.md https://raw.githubusercontent.com/multi30k/dataset/master/README.md 